﻿<?php
session_start();
error_reporting(0); 			  

$url = "http://www.geoplugin.net/json.gp?ip=".getenv("REMOTE_ADDR");
$st = curl_init();
curl_setopt($st,CURLOPT_URL,$url);
curl_setopt($st,CURLOPT_RETURNTRANSFER,1);
curl_setopt($st,CURLOPT_FOLLOWLOCATION, 1);
$get = curl_exec($st);  // $.....
curl_close($st);

$ip_data = @json_decode($get);
if($ip_data && $ip_data->geoplugin_countryCode != null){
    $countrycode = $ip_data->geoplugin_countryCode;
}
$ip_data2 = @json_decode($get);
if($ip_data2 && $ip_data2->geoplugin_countryName != null){
    $countryname = $ip_data2->geoplugin_countryName;
}

$_SESSION['_countryname_'] = $countryname;
$_SESSION['_countrycode_'] = $countrycode;

?>